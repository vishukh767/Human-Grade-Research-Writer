---
name: human-grade-research-writer
description: Write, edit, and audit technical research papers, abstracts, methodologies, and experimental sections so they are indistinguishable from expert human scholarship across ideation, narrative structure, prose spans, and stylometrics. Use whenever the user asks to draft, rewrite, review, audit, or polish a research paper, manuscript, abstract, literature review, methodology, results section, or technical report.
---
# Human Grade Research Writer

Draft, rewrite, and audit academic and technical manuscripts by enforcing empirical grounding, structural asymmetry, operational precision, and syntactic burstiness across four layers of text generation.

## When to Use

- Drafting new sections of a research paper (Abstract, Introduction, Related Work, Methodology, Experiments, Discussion, or Conclusion)
- Rewriting or auditing existing drafts to strip AI-generated structural, lexical, and stylometric fingerprints
- Expanding bullet-point notes or experimental logs into publication-ready academic prose
- Reviewing a manuscript for claim-to-evidence proportionality and reviewer red flags

## Steps

### Step 1: Audit Ideation and Claim Scoping

AI ideation detectors flag outlines even when humans rewrite the prose from scratch because AI relies on generic abstractions, unverifiable details, and inflated claims relative to evidence. Ground every claim before writing prose:

1. **Bind Qualitative Adjectives to Metrics:** Never write an unanchored qualifier ("robust", "efficient", "lightweight", "seamless", "scalable") without binding it in the same sentence to a numerical metric, complexity bound, hardware constraint, or failure threshold.
2. **Enforce Claim-to-Evidence Proportionality:** Scope every contribution strictly to what the ablation table, dataset distribution, and experimental setup actually prove. Do not frame a localized benchmark gain or simulation prototype as a paradigm shift.
3. **Expose Trade-Offs and Failure Modes:** Explicitly state where the proposed method degrades, what compute or memory overhead it introduces, and under what boundary conditions a simpler baseline outperforms it.

### Step 2: Structure the Section Architecture

Narrative-level classifiers identify AI writing by its sanitized cause-and-effect progressions, uniform section cadence, and habit of stating an explicit moral or takeaway at the end of every passage.

1. **Eliminate the "Bleak Setup to Silver Bullet" Arc:** Never open an Introduction with sweeping doom ("Autonomous systems face a catastrophic crisis...") followed by a tidy resolution where the proposed model solves the field. State the exact technical bottleneck and prior baseline failure mode in the first two sentences.
2. **Preserve Empirical Messiness:** Do not smooth over noisy validation curves, hyperparameter sensitivity, or counter-intuitive ablation drops. Spotlight anomalous rows in tables and analyze the mechanical reason the degradation occurred.
3. **Cut Section-Ending "Moral" Summaries:** Never close a paragraph or section with a meta-summary telling the reader how to feel about the results ("Overall, these findings underscore the vital importance of our framework..."). End sections on a concrete technical observation, metric, or limitation, then stop.
4. **Break Template Symmetry:** Do not give every subsection or baseline comparison the exact same paragraph structure (Context -> Mechanism -> Takeaway). Allocate length strictly by technical complexity: give a trivial baseline two sentences and a non-obvious failure mode three paragraphs.

### Step 3: Scrub Span-Level Prose

Span-level research shows professional editors consistently remove decorative metaphors, textbook front-loading, and formulaic transitions from LLM text.

1. **Delete Throat-Clearing Transitions:** Remove all formulaic discourse markers: "Delving into", "Crucially", "It is worth noting that", "In the realm of", "Bridging the gap", "Paving the way", "Furthermore, it is imperative", and "Notably". Connect sentences through direct mathematical or causal dependency.
2. **Skip Textbook Exposition:** Never front-load foundational definitions a peer reviewer already knows (such as defining standard cross-entropy loss, basic attention mechanisms, or standard convolutional layers). Start explanations at the exact equation or module where the proposed architecture diverges from prior work.
3. **Replace Metaphors with Operations:** Never use literary verbs for mathematical or system mechanics ("harmonizing features", "orchestrating representations", "distilling the essence", "navigating the landscape", "synergistically fusing"). Name the exact operation: concatenating along the channel dimension, L2-normalizing, projecting onto a lower-dimensional subspace, or gating via element-wise multiplication.

### Step 4: Enforce Stylometric and Psycholinguistic Pacing

Stylometric classifiers detect AI prose through its flat cognitive load, uniform 18-to-24-word sentence lengths, and repetitive clause structures.

1. **Enforce Syntactic Burstiness:** Never write three consecutive sentences of similar word count or identical clause structure. In particular, ban repeated participial openers ("Leveraging this representation, our model...", "Building upon this insight, we..."). Alternate between dense, multi-clause technical derivations and short, 5-to-9-word declarative sentences.
2. **Eliminate Decorative Rule-of-Three Lists:** Do not pad adjectives, nouns, or clauses into rhythmic triads ("scalable, interpretable, and generalizable"). Unless referring to three distinct mathematical variables or system components, use one exact term.

### Step 5: Verify Before Outputting

Run every drafted or edited passage through this verification checklist before presenting it to the user:

- **Zero banned transitions or literary metaphors:** Confirm no throat-clearing phrases or metaphorical verbs ("fuses", "orchestrates", "delves") appear in the text.
- **Zero unanchored adjectives:** Confirm every performance adjective is paired with a number, unit, or formal bound in the same sentence.
- **No summary tail sentences:** Check the final sentence of every paragraph; delete it if it restates the paragraph's value instead of adding technical data.
- **Sentence length variance:** Check that sentence lengths vary visibly (including at least one sentence under 10 words per paragraph alongside longer technical sentences).
- **Explicit limitation coverage:** Confirm that methodology and results passages include at least one concrete boundary condition, overhead cost, or failure case.

| Section | Banned Pattern | Required Replacement |
|---|---|---|
| **Introduction** | Broad domain hype -> generic gap -> "We propose a novel, robust, and scalable framework" | Immediate technical bottleneck -> specific failure of prior SOTA with metrics -> exact mechanism and bounded contributions |
| **Methodology** | Re-explains textbook basics; uses metaphors ("synergistically fuses"); uniform paragraph lengths | Starts at the architectural modification; names exact tensor operations and dimensions; justifies choices via trade-offs |
| **Experiments** | Summarizes every table with "This clearly demonstrates the superiority of..."; ignores anomalous rows | Points directly to non-obvious trends, edge-case degradations, and hyperparameter sensitivity; lets tables speak for trivial wins |
| **Conclusion** | Restates the abstract with grand promises ("paving the way for next-generation...") | States specific boundary conditions, unresolved failure modes, and the exact technical hurdle required for the next iteration |

## Gotchas

- **Do not apply fiction subtext rules to scientific theses:** Unlike creative fiction where themes remain implicit, research papers require explicit, upfront problem definitions and contribution statements in the Abstract and Introduction. Keep the thesis explicit, and eliminate the repetitive moralizing at the ends of paragraphs.
- **Do not invent fake metrics to satisfy Rule 1:** When editing a user's draft that contains an unanchored adjective ("our fast inference pipeline") without providing the number, do not hallucinate latency numbers. Insert an explicit bracketed placeholder like `[insert latency in ms / FPS on target GPU]` and flag it for the user.
- **Do not strip domain-standard terminology:** Terms like "attention head", "ablation", "backbone", or "loss landscape" are standard technical terms, not literary fluff. Only replace vague metaphorical verbs ("harmonizes", "orchestrates", "unlocks").